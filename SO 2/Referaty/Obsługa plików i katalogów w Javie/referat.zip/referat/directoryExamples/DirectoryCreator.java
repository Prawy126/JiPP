import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

final class DirectoryCreator {

    private DirectoryCreator() {
    }

    public static void main(String[] args) {
        String name = "NewCatalog";

        Path dir = Paths.get(name);

        if (Files.exists(dir)) {
            System.out.printf("Directory %s already exists!\n", name);
            System.exit(1);
        }

        try {
            Files.createDirectory(dir);
            System.out.printf("Directory %s created!\n", name);
        } catch (IOException e) {
            System.err.printf("Error when creating directory: %s\n", e.getMessage());
        }
    }
}
