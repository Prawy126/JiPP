import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

final class DirectoryMover {

    public static void main(String[] args) {
        Path src = Paths.get("dirToMove");
        Path dest = Paths.get("destination");

        if (!Files.exists(src) || !Files.exists(dest)) {
            System.out.println("Directories doesn't exists!");
            System.exit(1);
        }

        try {
            Path resolve = dest.resolve(src.getFileName());
            Files.move(src, resolve, REPLACE_EXISTING);
            System.out.printf("Directory %s moved!\n", src.getFileName());
        } catch (IOException e) {
            System.err.printf("Error when moving directory: %s\n", e.getMessage());
            System.exit(1);
        }
    }

}
