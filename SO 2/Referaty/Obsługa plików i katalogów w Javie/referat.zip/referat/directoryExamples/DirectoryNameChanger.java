import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

final class DirectoryNameChanger {

    public static void main(String[] args) {
        Path path = Paths.get("oldname");

        if (!Files.exists(path)) {
            System.out.printf("Directory %s doesn't exists!\n", path.getFileName());
            System.exit(1);
        }

        try {
            Files.move(path, path.resolveSibling("newname"));
            System.out.println("Name has been changed!");
        } catch (IOException e) {
            System.err.printf("Error when changing name of directory %s\n", e.getMessage());
        }
    }

}
