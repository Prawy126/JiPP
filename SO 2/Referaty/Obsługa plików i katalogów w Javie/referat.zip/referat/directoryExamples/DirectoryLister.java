import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import java.util.stream.Stream;


final class DirectoryLister {

    public static void main(String[] args) {
        String currentPath = System.getProperty("user.dir");
        Path currentDir = Paths.get(currentPath);

        try (Stream<Path> stream = Files.list(currentDir)) {

            stream.filter(Files::isDirectory)
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .collect(Collectors.toSet())
                    .forEach(System.out::println);

        } catch (IOException e) {
            System.err.printf("Error when listing files in directory %s", e.getMessage());
        }
    }

}
