import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

final class DirectoryRemover {

    public static void main(String[] args) {
        String name = "NewCatalog";

        Path dir = Paths.get(name);

        if (!Files.exists(dir)) {
            System.out.printf("Directory %s does not exist!\n", name);
            System.exit(1);
        }

        if (Objects.requireNonNull(dir.toFile().listFiles()).length > 0) {
            System.out.printf("Directory %s is not empty!\n", name);
            System.exit(1);
        }

        try {
            Files.delete(dir);
            System.out.printf("Directory %s deleted!\n", name);
        } catch (IOException e) {
            System.err.printf("Error when deleting directory: %s\n", e.getMessage());
            System.exit(1);
        }
    }
}
