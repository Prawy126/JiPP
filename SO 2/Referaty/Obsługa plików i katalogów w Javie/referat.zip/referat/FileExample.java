import java.io.*;
import java.nio.file.*;

public class FileExample {

    // Metoda do tworzenia nowego pustego pliku
    public static void createEmptyFile(String filePath) {
        File file = new File(filePath);
        try {
            if (file.createNewFile()) {
                System.out.println("Plik utworzony: " + filePath);
            } else {
                System.out.println("Plik już istnieje.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Metoda do tworzenia pliku z zawartością
    public static void createFileWithContent(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
            System.out.println("Plik z zawartością utworzony: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Metoda do odczytu pliku
    public static void readFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Metoda do zmiany nazwy pliku
    public static void renameFile(String oldFilePath, String newFilePath) {
        File oldFile = new File(oldFilePath);
        File newFile = new File(newFilePath);
        if (oldFile.renameTo(newFile)) {
            System.out.println("Nazwa pliku zmieniona na: " + newFilePath);
        } else {
            System.out.println("Nie udało się zmienić nazwy pliku.");
        }
    }

    // Metoda do przenoszenia pliku
    public static void moveFile(String sourceFilePath, String destinationFilePath) {
        Path sourcePath = Paths.get(sourceFilePath);
        Path destinationPath = Paths.get(destinationFilePath);
        try {
            Files.move(sourcePath, destinationPath);
            System.out.println("Plik przeniesiony do: " + destinationFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Metoda do kopiowania pliku
    public static void copyFile(String sourceFilePath, String destinationFilePath) {
        Path sourcePath = Paths.get(sourceFilePath);
        Path destinationPath = Paths.get(destinationFilePath);
        try {
            Files.copy(sourcePath, destinationPath);
            System.out.println("Plik skopiowany do: " + destinationFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Metoda do usuwania pliku
    public static void deleteFile(String filePath) {
        Path path = Paths.get(filePath);
        try {
            Files.delete(path);
            System.out.println("Plik usunięty: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        //dla testu najlepiej wywolywac sobie kazda metode pohjedynczo po kolei by widziec rezultaty
        createEmptyFile("testFile.txt");
        createFileWithContent("testFile.txt", "ala ma kota");
        readFile("testFile.txt");
        renameFile("testFile.txt", "newTestFile.txt");
        moveFile("newTestFile.txt", "movedTestFile.txt");
        copyFile("movedTestFile.txt", "copiedTestFile.txt");
        deleteFile("copiedTestFile.txt");

        //ustawianie uprawnien pliku

        try {
            Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("rw-r--r--");
            Files.setPosixFilePermissions(Paths.get("file.txt"), permissions);
            System.out.println("Permissions set successfully.");
        } catch (Exception e) {
            System.err.println("Error setting file permissions: " + e.getMessage());
        }

    }
}
