#include <stdio.h>
#include <stdlib.h>

int main() {
    char fileName[100];
	char newFileName[100];

    printf("Podaj aktualna nazwe pliku: ");
    scanf("%s", fileName);

    printf("Podaj nowa nazwe pliku: ");
    scanf("%s", newFileName);

    if (rename(fileName, newFileName) == 0) {
        printf("Zmiana nazwy pliku udana.\n");
    } else {
        printf("B�ad podczas zmiany nazwy pliku.\n");
    }

    return 0;
}

