#include <stdio.h>

int main() {
	FILE *out;
	char tekst[1201];

	if((out = fopen("write.txt", "wt")) == NULL) 
	{
		printf("Nie mozna otworzyc pliku");
		return 1;
	}

	printf("Podaj tekst: ");
	scanf(" %[^\n]", tekst);

	fprintf(out, "\nWprowadzony tekst: %s", tekst);

	fclose(out);

	printf("Tekst zostal zapisany w pliku");
	getchar();
	return 0;
}

