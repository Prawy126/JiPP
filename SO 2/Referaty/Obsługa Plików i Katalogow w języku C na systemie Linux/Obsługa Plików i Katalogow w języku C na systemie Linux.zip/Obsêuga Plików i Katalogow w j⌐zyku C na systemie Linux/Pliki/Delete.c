#include <stdio.h>

int main() {
    char filename[] = "delete_file.txt";

    if (remove(filename) == 0) {
        printf("Plik %s usuniety pomyslnie.\n", filename);
    } else {
        perror("Nie mozna usunac pliku ktory nie istnieje");
    }

    return 0;
}

