#include <stdio.h>

int main() {
    const char* file = "empty.txt";

    FILE* plik = fopen(file, "wb");

    if (plik == NULL) {
        printf("Nie uda�o si� otworzy� pliku.\n");
        return 1;
    }

    fclose(plik);

    printf("Pusty plik \"%s\" zostal utworzony.\n", file);

    return 0;
}

