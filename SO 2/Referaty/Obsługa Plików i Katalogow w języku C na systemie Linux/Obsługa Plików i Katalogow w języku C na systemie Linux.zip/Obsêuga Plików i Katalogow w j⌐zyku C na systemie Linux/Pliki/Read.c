#include <stdio.h> 

int main() {
	
	FILE *fp;
	char bufor[1201];
	
	if ((fp = fopen("file.txt", "rt")) == NULL) 
	{
		printf("Nie mozna otworzyc pliku");
		return 1;
	}
	
	while (feof(fp)==0){
		fgets(bufor, 512, fp);
		printf("%s", bufor);
	}
	
	fclose(fp);
	return 0;
}
