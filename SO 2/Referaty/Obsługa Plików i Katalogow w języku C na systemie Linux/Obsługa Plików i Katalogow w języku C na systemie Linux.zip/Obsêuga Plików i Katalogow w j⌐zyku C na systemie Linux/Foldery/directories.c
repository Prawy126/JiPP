#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <limits.h>
#include <sys/stat.h>
#include <sys/types.h>

char *pwd() {
    char *cwd = malloc(PATH_MAX); // Allocate memory for the path
    if (getcwd(cwd, PATH_MAX) != NULL) {
        return cwd;
    } else {
        perror("getcwd() error");
        exit(EXIT_FAILURE);
    }
}

void ls(const char *path) {
    DIR *dir;
    struct dirent *entry;

    if ((dir = opendir(path)) == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    while ((entry = readdir(dir)) != NULL) {
        printf("%s\n", entry->d_name);
    }

    closedir(dir);
}

void createDirectory(const char *directoryName) {
    if (mkdir(directoryName, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == 0) {
        printf("Directory '%s' created successfully.\n", directoryName);
    } else {
        perror("mkdir() error");
        exit(EXIT_FAILURE);
    }
}

void changeDirectory(const char *path) {
    if (chdir(path) == 0) {
        printf("Changed directory to: %s\n", path);
    } else {
        perror("chdir() error");
        exit(EXIT_FAILURE);
    }
}

void removeDirectory(const char *path) {
    if (rmdir(path) == 0) {
        printf("Directory '%s' removed successfully.\n", path);
    } else {
        perror("rmdir() error");
        exit(EXIT_FAILURE);
    }
}

void moveFile(const char *source, const char *destination) {
    if (rename(source, destination) == 0) {
        printf("Pomyślnie przeniesiono '%s' do '%s'.\n", source, destination);
    } else {
        perror("Błąd rename()");
        exit(EXIT_FAILURE);
    }
}

void copyFile(const char *source, const char *destination) {
    FILE *sourceFile, *destinationFile;
    char buffer[1024];
    size_t bytesRead;

    sourceFile = fopen(source, "rb");
    if (sourceFile == NULL) {
        perror("fopen() error for source file");
        exit(EXIT_FAILURE);
    }

    destinationFile = fopen(destination, "wb");
    if (destinationFile == NULL) {
        perror("fopen() error for destination file");
        fclose(sourceFile);
        exit(EXIT_FAILURE);
    }

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), sourceFile)) > 0) {
        fwrite(buffer, 1, bytesRead, destinationFile);
    }

    fclose(sourceFile);
    fclose(destinationFile);
}

void copyDirectory(const char *source, const char *destination) {
    DIR *dir;
    struct dirent *entry;

    // Create the destination directory if it doesn't exist
    mkdir(destination, 0777);

    dir = opendir(source);
    if (dir == NULL) {
        perror("opendir() error for source directory");
        exit(EXIT_FAILURE);
    }

    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            char sourcePath[PATH_MAX];
            char destinationPath[PATH_MAX];

            snprintf(sourcePath, PATH_MAX, "%s/%s", source, entry->d_name);
            snprintf(destinationPath, PATH_MAX, "%s/%s", destination, entry->d_name);

            if (entry->d_type == DT_REG) {
                // Regular file, copy it
                copyFile(sourcePath, destinationPath);
            } else if (entry->d_type == DT_DIR) {
                // Subdirectory, copy it recursively
                copyDirectory(sourcePath, destinationPath);
            }
        }
    }

    closedir(dir);
}

void changePermissions(const char *path, mode_t newPermissions) {
    if (chmod(path, newPermissions) == 0) {
        printf("Changed permissions of '%s' to %o successfully.\n", path, newPermissions);
    } else {
        perror("chmod() error");
        exit(EXIT_FAILURE);
    }
}

int main() {
    char* current_dir = pwd();
    // printf("current directory: %s\n", current_dir);
    // ls(current_dir);
    const char *directoryName = "c_created_directory";
    // createDirectory(directoryName);
    // printf("current directory: %s\n", pwd());
    // changeDirectory(directoryName);
    // printf("current directory: %s\n", pwd());
    // ls(current_dir);
    // removeDirectory(directoryName);
    // ls(current_dir);
    // const char *ścieżkaŹródłowa = "c_created_directory";
    // const char *ścieżkaDocelowa = "example_directory/c_created_directory_renamed";
    // moveFile(ścieżkaŹródłowa, ścieżkaDocelowa);
    // const char *sourceDirectory = "example_directory";
    // const char *destinationDirectory = "example_directory_2";

    // copyDirectory(sourceDirectory, destinationDirectory);
    const char *filePath = "example_directory";
    mode_t newPermissions = strtol("0777", NULL, 8);

    changePermissions(filePath, newPermissions);


    return 0;
}