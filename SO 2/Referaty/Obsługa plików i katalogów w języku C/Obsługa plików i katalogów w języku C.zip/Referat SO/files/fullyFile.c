#include<stdio.h>

int main() {
	
	const char *name = "file.txt";
	
	FILE *file_pointer = fopen(name, "w");
	
	if (file_pointer == NULL) {
    	perror("File creation error");
	}
	else {
		
		fprintf(file_pointer, "%s", "Ala ma kota\n");
		fprintf(file_pointer, "%s", "a kot ma Ale");
		
		fclose(file_pointer);
	}
	
	return 0;
}




