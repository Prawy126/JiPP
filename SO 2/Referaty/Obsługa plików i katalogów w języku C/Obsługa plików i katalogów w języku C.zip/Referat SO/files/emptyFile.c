#include<stdio.h>

int main() {
	
	const char *name = "empty.txt";
	
	FILE *file_pointer = fopen(name, "w");
	
	if (file_pointer == NULL) {
    	perror("File creation error");
	}
	else {
		printf("File %s created successfully!", name);
		fclose(file_pointer);
	}
	
	return 0;
}


