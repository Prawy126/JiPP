#include<stdio.h>

int main() {
	
	FILE *file_pointer = fopen("file.txt", "r");
	
	if (file_pointer == NULL) {
    	perror("File opening error");
	}
	else {
		
		char line[1200 + 1];

    	while (fgets(line, sizeof(line), file_pointer) != NULL) {
			printf("%s", line);
		}		
		
		fclose(file_pointer);		
	}
	
	return 0;
}
